import React, { Component } from "react";
import MainAdmin from "../components/MainAdmin";

export default class Admin extends Component {
  render() {
    return (
      <div>
        <MainAdmin />
      </div>
    );
  }
}
